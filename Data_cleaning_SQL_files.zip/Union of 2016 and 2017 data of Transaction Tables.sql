-- make single table with year in it 

Select * into STG_PU_DRG_MAIN 
from 
(select *, '2016' as Year from [dbo].[SRC_PU_DRG_2016] union all select *, '2017' as Year from [dbo].[SRC_PU_DRG_2017]) as t1

select * from STG_PU_DRG_MAIN

select distinct[specialty_description] from STG_PU_DRG_MAIN
where [specialty_description] like 'Den%'

--Replacing Denturist to Denist
UPDATE STG_PU_DRG_MAIN
SET [specialty_description]='Dentist'
WHERE [specialty_description]='Denturist'

select distinct[specialty_description] from STG_PU_DRG_MAIN
where [specialty_description] like 'All%'

--Updating Allergy/Immunology
UPDATE STG_PU_DRG_MAIN
SET [specialty_description]='Allergy/ Immunology'
WHERE [specialty_description]='Allergy/Immunology'

ALTER TABLE STG_PU_DRG_MAIN
ADD Comment varchar(50);

UPDATE STG_PU_DRG_MAIN
SET Comment='Count between 1 and 10'
WHERE [bene_count_ge65_suppress_flag]='*'

UPDATE STG_PU_DRG_MAIN
SET Comment='Less than 65 yrs and count between 1 and 10'
WHERE [bene_count_ge65_suppress_flag]='#'



