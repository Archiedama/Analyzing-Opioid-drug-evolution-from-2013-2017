--display all values from table
--select * from [dbo].[STG1_BP_ERL]

--Count of rows which have wrong STATE_CD
--select [STATE_CD],count(*) from [dbo].[STG1_BP_ERL]
--group by state_cd
--having len(state_cd) > 2

--Displaying the rows with wrong STATE_CD
--select * from [dbo].[STG1_BP_ERL]
--where state_cd like '%CLIN%'

-- copying columns with state_CD CLIN to new table
--SELECT *
--INTO STG_BP_ERL_CLEAN 
--FROM [dbo].[STG1_BP_ERL]
--WHERE STATE_CD like '%CLIN%'

--New table
--select * from STG_BP_ERL_CLEAN 

-- Updating the values of the new table
--Update STG_BP_ERL_CLEAN 
--Set STATE_CD = FIRST_NAME, FIRST_NAME= MDL_NAME, MDL_NAME=LAST_NAME, LAST_NAME=ORG_NAME
--where State_cd LIKE '%CLIN%'

--After deleting rows with wrong values in old table
--Replace the values from the new table into old table

--INSERT INTO [dbo].[STG1_BP_ERL]
--SELECT * FROM STG_BP_ERL_CLEAN 

--select distinct(provider_type_desc) from  [dbo].[STG1_BP_ERL] 
--clean provider_type_desc
--update [dbo].[STG1_BP_ERL] set provider_type_desc = REPLACE(provider_type_desc, '"', '') 

--select count(*) from [dbo].[STG1_BP_ERL] 


