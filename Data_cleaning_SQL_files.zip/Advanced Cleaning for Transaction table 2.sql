-- Error handelling for Transaction Table

SELECT  [npi]
      ,[nppes_provider_last_org_name]
      ,[nppes_provider_first_name]
      ,[nppes_provider_city]
      ,[nppes_provider_state]
      ,[specialty_description]
      ,[description_flag]
      ,[drug_name]
      ,[generic_name]
      ,[bene_count]
      ,[total_claim_count]
      ,[total_30_day_fill_count]
      ,[total_day_supply]
      ,[total_drug_cost]
      ,[bene_count_ge65]
      ,[bene_count_ge65_suppress_flag]
      ,[total_claim_count_ge65]
      ,[ge65_suppress_flag]
      ,[total_30_day_fill_count_ge65]
      ,[total_day_supply_ge65]
      ,[total_drug_cost_ge65] into ERR_DRG_PU_1
  FROM [HuskyCodersProject Base].[dbo].[SRC_PU_DRG_2017]
  where [nppes_provider_last_org_name] like '"%' or 
  [nppes_provider_first_name] like '"%' or 
      [nppes_provider_city] like '"%' or 
      [nppes_provider_state] like '"%' or 
      [specialty_description] like '"%' or 
      [description_flag] like '"%' or 
     [drug_name] like '"%' or 
      [generic_name] like '"%' 
-- Get the count of error Rows
SELECT Count(*)
FROM [HuskyCodersProject Base].[dbo].[SRC_PU_DRG_2017]
where [nppes_provider_last_org_name] like '"%' or 
[nppes_provider_first_name] like '"%' or 
[nppes_provider_city] like '"%' or 
[nppes_provider_state] like '"%' or 
[specialty_description] like '"%' or 
[description_flag] like '"%' or 
[drug_name] like '"%' or 
[generic_name] like '"%' 
-- confirm the number of records
Select Count(*) from [dbo].[ERR_DRG_PU_1]
-- Delete from original Data Base
Delete [SRC_PU_DRG_2017] 
where [nppes_provider_last_org_name] like '"%' or 
[nppes_provider_first_name] like '"%' or 
[nppes_provider_city] like '"%' or 
[nppes_provider_state] like '"%' or 
[specialty_description] like '"%' or 
[description_flag] like '"%' or 
[drug_name] like '"%' or 
[generic_name] like '"%' 
---- Cast and move to new table
SELECT  Cast([npi] as varchar(10)) as npi
      ,Cast([nppes_provider_last_org_name] as varchar(50)) as [nppes_provider_last_org_name]
      ,Cast([nppes_provider_first_name] as varchar(50)) as [nppes_provider_first_name]
      ,Cast([nppes_provider_city] as varchar(30)) as [nppes_provider_city]
      ,Cast([nppes_provider_state] as varchar(20)) as [nppes_provider_state]
      ,Cast([specialty_description] as varchar(100)) as [specialty_description]
      ,Cast([description_flag] as varchar(10)) as [description_flag]
      ,cast([drug_name] as varchar(50)) as [drug_name]
      ,cast([generic_name] as varchar(50)) as [generic_name]
      ,Cast([bene_count] as int)  as [bene_count]
      ,cast([total_claim_count] as int) as [total_claim_count]
      ,cast([total_30_day_fill_count] as float) as [total_30_day_fill_count]
      ,Cast([total_day_supply] as float) as [total_day_supply]
      ,Cast([total_drug_cost] as float) as [total_drug_cost]
      ,Cast([bene_count_ge65] as float) as [bene_count_ge65]
      ,Cast([bene_count_ge65_suppress_flag] as varchar(2))  as [bene_count_ge65_suppress_flag]
      ,cast([total_claim_count_ge65] as int) as [total_claim_count_ge65]
      ,cast([ge65_suppress_flag] as varchar(2)) as [ge65_suppress_flag]
      ,cast([total_30_day_fill_count_ge65] as float) as [total_30_day_fill_count_ge65]
      ,Cast([total_day_supply_ge65] as float) as [total_day_supply_ge65]
      ,cast([total_drug_cost_ge65] as float) as [total_drug_cost_ge65]
	  into STG_DRG_PU_2017
  FROM [HuskyCodersProject Base].[dbo].[SRC_PU_DRG_2017]
