-- Building realtionships 

-- connecting the City and the state Dimension

Alter table [dbo].[DIM_GEO_CITY]
Alter Column [city_id] bigint not null

ALter Table [dbo].[DIM_GEO_CITY]
add primary key ([city_id])

-- adding realtionship to GEO_STATE
Alter table [dbo].[DIM_GEO_STATE]
alter column [state_id] varchar(10) not null

alter table [dbo].[DIM_GEO_STATE]
add primary key ([state_id]) 

Alter table [dbo].[DIM_GEO_CITY]
add foreign key ([state_id]) references [dbo].[DIM_GEO_STATE]([state_id])

-- adding unique columns to all the dimensions used
alter table [dbo].[DIM_DRUG]
alter column [DrugID] bigint not null

alter table [dbo].[DIM_DRUG]
add primary key ([DrugID])

-- adding unique columns to DIM_ENRLMT

alter table [dbo].[DIM_ENRLMT]
alter column [NPI] varchar(15) not null
alter table [dbo].[DIM_ENRLMT]
alter column [ENRLMT_ID] varchar(20) not null

alter table [dbo].[DIM_ENRLMT]
add constraint NPI_ENRLMNT primary key (NPI,ENRLMT_ID)
-- adding uniqe primary key columns to DIM_PROVIDER HEADER
Alter table [dbo].[DIM_PROVIDER_HEADER]
alter column [NPI] varchar(15) not null 

alter table [dbo].[DIM_PROVIDER_HEADER]
add primary key (NPI)

alter table [dbo].[DIM_SP_TAX]
alter column [MEDICATE_SPECIALITY_CODE] char(10) not null

alter table [dbo].[DIM_SP_TAX]
add primary key ([MEDICATE_SPECIALITY_CODE])

--- create relationships 
alter table [dbo].[FCT_PU_DRG]
alter column [npi] varchar(15) null

ALter table [dbo].[FCT_PU_DRG]
add foreign key ([npi]) references [dbo].[DIM_PROVIDER_HEADER]([NPI])

alter table [dbo].[FCT_PU_DRG]
add foreign key ([city_id]) references [dbo].[DIM_GEO_CITY]([city_id])

alter table [dbo].[FCT_PU_DRG]
alter column [MEDICATE_SPECIALITY_CODE] char(10) null

alter table [dbo].[FCT_PU_DRG]
add foreign key ([MEDICATE_SPECIALITY_CODE]) references [dbo].[DIM_SP_TAX]([MEDICATE_SPECIALITY_CODE])

alter table [dbo].[FCT_PU_DRG]
add foreign key ([DrugID]) references [dbo].[DIM_DRUG]([DrugID])