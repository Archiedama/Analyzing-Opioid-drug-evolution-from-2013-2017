-- check the different drug names
Select Distinct [drug_name], [generic_name]  into Drug_table from [HuskyCodersProject Base].[dbo].[STG_PU_DRG_MAIN]

Select [Drug Name],[Generic Name] ,[Comment], drug_name,[generic_name] into DRUG_HEAD  from [dbo].[SCD_OD_LST] t1 Full outer join 
[dbo].[Drug_table] t2 on t1.[Drug Name] = t2.drug_name
-- creating DIM_DRUG
Select row_number() over (order by [drug_name]) as DrugID,
Case when [drug_name] is null then [Drug Name] else [drug_name] end as [DRUG_NAME]  ,
Case when [generic_name] is null then [Generic Name] else [generic_name] end as [GENERIC_NAME] ,
[Comment],
Case when [Comment] is null then 'N' else 'Y' end as Opioid_Drug_Flag
into DIM_DRUG
from DRUG_HEAD