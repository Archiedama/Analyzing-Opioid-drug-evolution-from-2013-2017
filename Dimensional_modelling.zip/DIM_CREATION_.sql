--Creating DIM_ENRLMT Table
--use[HuskyCodersProject Base]
--go

--SELECT DISTINCT [ENRLMT_ID],[NPI],[STATE_CD]
--INTO [HuskyCodersProject DW].[dbo].[DIM_ENRLMT]
--FROM [HuskyCodersProject Base].[dbo].[STG1_BP_ERL]

--use [HuskyCodersProject DW]
--go 

select * from [dbo].[DIM_ENRLMT] order by NPI


--create DIM_NPI
--use[HuskyCodersProject Base]
--go

--Creating a TEMP_NPI table with required columns
--SELECT DISTINCT [NPI],[PECOS_ASCT_CNTL_ID],[PROVIDER_TYPE_CD],[PROVIDER_TYPE_DESC],[FIRST_NAME],[MDL_NAME],[LAST_NAME],[ORG_NAME],[GNDR_SW]
--INTO [HuskyCodersProject Base].[dbo].[TEMP_NPI]
--FROM [HuskyCodersProject Base].[dbo].[STG1_BP_ERL]

SELECT TOP 10 * FROM [TEMP_NPI]

SELECT DISTINCT([PROVIDER_TYPE_CD]) FROM [dbo].[TEMP_NPI] 

--Creating two new columns to transfer the data from split columns
--ALTER TABLE [TEMP_NPI] 
--ADD [PROVIDER_TYPE_CD_1] varchar(10),[PROVIDER_TYPE_CD_2] varchar(10);

-- splitting [PROVIDER_TYPE_CD] based on '-'
--Update [TEMP_NPI] 
--SET PROVIDER_TYPE_CD_1 = SUBSTRING(PROVIDER_TYPE_CD, 1, CHARINDEX('-',PROVIDER_TYPE_CD ) - 1)  , 
-- PROVIDER_TYPE_CD_2 = SUBSTRING(PROVIDER_TYPE_CD, CHARINDEX('-', PROVIDER_TYPE_CD) + 1, LEN(PROVIDER_TYPE_CD)) 

-- remove column [PROVIDER_TYPE_CD]
--ALTER TABLE [dbo].[TEMP_NPI]
--DROP COLUMN [PROVIDER_TYPE_CD];

select  distinct([PROVIDER_TYPE_DESC]) from [dbo].[TEMP_NPI]

SELECT TOP 5 LEN([PROVIDER_TYPE_DESC]) FROM [dbo].[TEMP_NPI] ORDER BY LEN([PROVIDER_TYPE_DESC]) DESC


--Creating two new columns to transfer the data from split columns
--ALTER TABLE [TEMP_NPI] 
--ADD [PROVIDER_TYPE_DESC_1] varchar(100),[PROVIDER_TYPE_DESC_2] varchar(100);

-- splitting [PROVIDER_TYPE_DESC] based on '-'
--Update [TEMP_NPI] 
--SET PROVIDER_TYPE_DESC_1 = SUBSTRING(PROVIDER_TYPE_DESC, 1, CHARINDEX('-',PROVIDER_TYPE_DESC ) - 1)  , 
-- PROVIDER_TYPE_DESC_2 = SUBSTRING(PROVIDER_TYPE_DESC, CHARINDEX('-', PROVIDER_TYPE_DESC) + 1, LEN(PROVIDER_TYPE_DESC)) 

 -- remove column [PROVIDER_TYPE_DESC]
--ALTER TABLE [dbo].[TEMP_NPI]
--DROP COLUMN [PROVIDER_TYPE_DESC];

SELECT * FROM [dbo].[TEMP_NPI] where [PROVIDER_TYPE_CD_2]='13'

--rename column PROVIDER_TYPE_CD_2 to MEDICATE_SPECIALITY_CODE

SELECT count(*) FROM [dbo].[TEMP_NPI] where MEDICATE_SPECIALITY_CODE='14'

-- rename column [PROVIDER_TYPE_DESC_2] to supplier type 

-- checking if all NPI are unique 
select distinct(npi), count(*) from [TEMP_NPI]
group by npi
having count(npi) >1

-- we have few NPI repeated twice because there is slight variation in the name of the organization
select * from [TEMP_NPI] where npi ='1437553583'

--Transfer data from [TEMP_NPI] to DIM_NPI Table in [HuskyCodersProject DW]
--SELECT *
--INTO [HuskyCodersProject DW].[dbo].[DIM_NPI]
--FROM [HuskyCodersProject Base].[dbo].[TEMP_NPI]


select * into DIM_PROV
FROM [dbo].[DIM_PROVIDER_NPI]

SELECT TOP 10 * FROM DIM_PROV

select count(distinct([ENRLMT_ID])) from [dbo].[DIM_ENRLMT]
select count([ENRLMT_ID]) from [dbo].[DIM_ENRLMT]
SELECT TOP 10 * FROM DIM_PROVIDER

select distinct([PECOS_ASCT_CNTL_ID]), count(*) from DIM_PROV
group by [PECOS_ASCT_CNTL_ID]
having count([PECOS_ASCT_CNTL_ID]) >10


select * from [dbo].[DIM_PROVIDER_NPI] where [PECOS_ASCT_CNTL_ID] ='3577548452'

select distinct([PECOS_ASCT_CNTL_ID]),[FIRST_NAME],[MDL_NAME],[LAST_NAME],[ORG_NAME],[GNDR_SW]
into DIM_PRO
FROM DIM_PROV

select count(distinct([PECOS_ASCT_CNTL_ID])) from DIM_PRO
select count([PECOS_ASCT_CNTL_ID]) from DIM_PRO

select distinct([PECOS_ASCT_CNTL_ID]), count(*) from DIM_PRO
group by [PECOS_ASCT_CNTL_ID]
having count([PECOS_ASCT_CNTL_ID]) >1

WITH CTE AS(
   SELECT [PECOS_ASCT_CNTL_ID],[FIRST_NAME],[MDL_NAME],[LAST_NAME],[ORG_NAME],[GNDR_SW],
       RN = ROW_NUMBER()OVER(PARTITION BY [PECOS_ASCT_CNTL_ID] ORDER BY [PECOS_ASCT_CNTL_ID])
   FROM DIM_PRO 
)
DELETE FROM CTE WHERE RN > 1

SELECT DISTINCT(NPI) 
INTO DIM_MASTER_NPI
FROM [HuskyCodersProject Base].[dbo].[TEMP_NPI]

SELECT TOP 100 * FROM DIM_MASTER_NPI