/****** Script for SelectTopNRows command from SSMS  ******/
SELECT [NPI]
      ,[PECOS_ASCT_CNTL_ID]
      ,[FIRST_NAME]
      ,[MDL_NAME]
      ,[LAST_NAME]
      ,[ORG_NAME]
      ,[GNDR_SW]
      ,[PROVIDER_TYPE_CD_1]
      ,[MEDICATE_SPECIALITY_CODE]
      ,[PROVIDER_TYPE_DESC_1]
      ,[SUPPLIER_TYPE]
  FROM [HuskyCodersProject Base].[dbo].[TEMP_NPI]
  where  [FIRST_NAME] like '"%' or
  [MDL_NAME] like '"%' or
  [LAST_NAME] like '"%' or
  [ORG_NAME]  like '"%' or
  [GNDR_SW] like '"%' 

  Delete [dbo].[TEMP_NPI]
    where  [FIRST_NAME] like '"%' or
  [MDL_NAME] like '"%' or
  [LAST_NAME] like '"%' or
  [ORG_NAME]  like '"%' or
  [GNDR_SW] like '"%' 

  Use [HuskyCodersProject DW]


GO

/****** Object:  Table [dbo].[TEMP_NPI]    Script Date: 04/24/2020 12:47:37 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DIM_PROVIDER_HEADER](
	[NPI] [varchar](15) NULL,
	[PECOS_ASCT_CNTL_ID] [varchar](15) NULL,
	[FIRST_NAME] [varchar](30) NULL,
	[MDL_NAME] [varchar](30) NULL,
	[LAST_NAME] [varchar](35) NULL,
	[ORG_NAME] [varchar](75) NULL,
	[GNDR_SW] [varchar](5) NULL,
	[PROVIDER_TYPE_CD_1] [varchar](10) NULL,
	[MEDICATE_SPECIALITY_CODE] [varchar](10) NULL,
	[PROVIDER_TYPE_DESC_1] [varchar](100) NULL,
	[SUPPLIER_TYPE] [varchar](100) NULL
) ON [PRIMARY]
GO

insert into [DIM_PROVIDER_HEADER]
select * from [HuskyCodersProject Base].[dbo].[TEMP_NPI]

  
